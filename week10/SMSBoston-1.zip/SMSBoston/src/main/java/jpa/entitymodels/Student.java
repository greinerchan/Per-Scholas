package jpa.entitymodels;

public class Student {

}
