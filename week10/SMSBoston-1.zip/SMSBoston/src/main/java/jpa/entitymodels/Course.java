package jpa.entitymodels;

public class Course {

}
