package com.dao;

public abstract class DataSourceDAO {
	
	//Complete this class to establish the database connection
	
}
