package com.application;

public class RestaurantCentral {

	public static void main(String[] args) {
		
		//Demo your application here to display all the functionalities of
		//interfaces

	}

}
