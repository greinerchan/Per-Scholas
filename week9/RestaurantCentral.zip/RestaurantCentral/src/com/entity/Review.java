package com.entity;

import java.util.Objects;

public class Review {
	private int id; //01
	private String content;
	private String writtenBy;
	private int rating;
}
