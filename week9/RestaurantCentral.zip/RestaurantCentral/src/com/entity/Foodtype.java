package com.entity;

public class Foodtype {
	private int id; //01
	private String name; //Sea food
}
