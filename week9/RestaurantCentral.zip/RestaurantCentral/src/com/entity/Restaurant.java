package com.entity;

import java.util.Objects;

public class Restaurant {
  private int id;
  private String name;
  private String address;
  private String zipcode;
  private String phone;
  private String website;
  private String email;
}
