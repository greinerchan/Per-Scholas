package com.perscholas.junitbasic.testsuite;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class Suite1Test {
	@Test
	public void testSuite1() {
		assertTrue(true);
	}
}
