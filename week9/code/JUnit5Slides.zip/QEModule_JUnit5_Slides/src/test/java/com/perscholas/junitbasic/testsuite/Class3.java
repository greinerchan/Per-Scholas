package com.perscholas.junitbasic.testsuite;

import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.Test;

public class Class3 {

	@Test
	public void testClass3() {
		assertFalse(false);
	}
	
}
