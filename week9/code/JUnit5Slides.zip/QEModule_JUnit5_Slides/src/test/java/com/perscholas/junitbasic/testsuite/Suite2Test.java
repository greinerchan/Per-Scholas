package com.perscholas.junitbasic.testsuite;

import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.Test;

public class Suite2Test {
	@Test
	public void testSuite2() {
		assertFalse(false);
	}
}
