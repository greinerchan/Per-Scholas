package com.perscholas.junitbasic.testsuite;

import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.Test;

public class Class2Test {

	@Test
	public void testClass2() {
		assertFalse(false);
	}
	
}
