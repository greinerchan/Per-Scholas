package wednesday.exceptions;


public class Main {

	public static void main(String[] args) throws Exception {
			MyExceptions.readFile("/Users/Habboubi/eclipse-workspace/Boston-Week6/src/wednesday/readthisfile.txt");
	}

}
