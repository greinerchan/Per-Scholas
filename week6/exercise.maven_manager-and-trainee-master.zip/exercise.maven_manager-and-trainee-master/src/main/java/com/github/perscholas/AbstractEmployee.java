package com.github.perscholas;

/**
 * Created by leon on 6/10/2020.
 */
// TODO - Ensure an `AbstractEmployee` implements the `EmployeeInterface`
// TODO - Ensure an `AbstractEmployee` is abstract
public class AbstractEmployee {
    private Object exampleOfInstanceVariable; // TODO - Replace with correct instance variable declarations

    // TODO - Ensure that each of the arguments passed through the constructor are assigned to a respective instance variable
    private AbstractEmployee(Long id, String name, String address, Long phoneNumber, Double basicSalary, Double specialAllowance, Double healthReimbursementAccount) {
    }

    // TODO - Ensure that each of the arguments passed through the constructor are assigned to a respective instance variable
    public AbstractEmployee(Long id, String name, String address, Long phoneNumber, Double basicSalary) {
    }

    public AbstractEmployee() {
    }
}
