package com.github.perscholas;

public class ApplicationRunner implements Runnable {
    public void run() {
        /**
         * TODO - Create an instance of `Manager`.
         * Ensure the `Manager` instance is constructed with each of the following field-values:
         * -- id: 126534
         * -- name: "Peter"
         * -- address: "Chennai India"
         * -- phone: 237844
         * -- salary: 65000
         *
         * TODO - Create an instance of `Trainee`
         * Ensure the `Trainee` instance is constructed with each of the following field-values:
         * -- id: 29846
         * -- name: "Jack"
         * -- address: "Mumbai India"
         * -- phone: 442085
         * -- salary: 45000
         *
         * TODO - Invoke `calculateSalary` method on `manager` instance
         * The salary calculated should be printed in the console
         *
         * TODO - Invoke `calculateSalary` method on `trainee` instance
         * The salary calculated should be printed in the console
         *
         */
    }
}
