package com.github.perscholas;

/**
 * Created by leon on 6/10/2020.
 */
public class StoneMonster {
}
