package com.github.perscholas;

public class FireMonster {
}
