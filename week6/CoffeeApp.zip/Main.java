import java.util.Scanner;

class Main {
    static final double SALES_TAX = 0.625;

    public static void main(String[] args) {
        Coffee coffee = new Coffee();
        Cappuccino cappuccino = new Cappuccino(); 
        Expresso expresso = new Expresso();

        Scanner input = new Scanner(System.in);
        System.out.println("Welcome to JVXI coffeePrice shop!");
        printMenu();
        int userChoice = input.nextInt();
        switch (userChoice) {
        case 1: 
            System.out.println("How many cups of Coffee do you want?");
            int quantity = input.nextInt();
            coffee.setQuantity(quantity);
            break;
        case 2:
            
            break;
        case 3:

        }

    }

    // enum items {
    // COFFEE, CAPUCCINO, EXPRESSO, CHECKOUT;
    // }
    private static void printMenu() {
        System.out.println(" Please select from the following menu: ");

        System.out.println("1: Coffee \n2: Capuccino \n3: Expresso \n4: Checkout");
        System.out.print("Enter your choice: ");
    }

    private static double calculateProductTotal(double coffeePrice, double espressoPrice, double cappuccinoPrice) {
        return coffeePrice + espressoPrice + cappuccinoPrice + SALES_TAX;
    }
}