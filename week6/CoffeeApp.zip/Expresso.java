public Expresso extends Product {
    private boolean extraShot;
    private boolean macchiato;
    private final double MACCHIATO_EXTRA_CHARGE = 1; 
    private final double EXTRA_SHOT_PRICE = 2;

    public Expresso() {
        super(null, 0, null);
        this.extraShot = false;
        this.macchiato = false;
    }

    public Expresso(String name, double price, String description, boolean extraShot, boolean macchiato,) {
        super(name, price, description);
        this.extraShot = extraShot;
        this.macchiato = macchiato;
    }


    public boolean isExtraShot() {
        return this.extraShot;
    }

    public void setExtraShot(boolean extraShot) {
        this.extraShot = extraShot;
    }

    public boolean isMacchiato() {
        return this.macchiato;
    }

    public void setMacchiato(boolean macchiato) {
        this.macchiato = macchiato;
    }

    @Override
    public double calculateProductSubTotal(int quantity) {
        double subtotal = quantity * this.price;
        if(isMacchiato()){
            subtotal += quantity * MACCHIATO_EXTRA_CHARGE;
        } 
        if(isExtraShot) {
            subtotal += quantity * EXTRA_SHOT_PRICE;
        }

        return subtotal;
    }

}