package com.myproject.b2c.sunshine.entity;

import lombok.Data;

import javax.persistence.*;

@Entity
@Table(name = "user")
@Data
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "user_nickname")
    private String userNickName;

    @Column(name = "user_password")
    private String userPassword;

    @Column(name = "user_realname")
    private String userRealName;

    @Column(name = "user_gender")
    private String userGender;

    @Column(name = "user_birthday")
    private String userBirthday;

    @Column(name = "user_address")
    private String userAddress;

    @Column(name = "user_homeplace")
    private String userHomeplace;

    @Column(name = "user_profile_picture_src")
    private String userProfilePictureSrc;
}
