package com.myproject.b2c.sunshine.entity;


import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name="product")
@Data
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private Category category;

    @Column(name = "product_name")
    private String productName;

    @Column(name = "product_title")
    private String productTitle;

    @Column(name = "product_price")
    private BigDecimal productPrice;

    @Column(name = "product_create_date")
    private Date productCreateDate;

    @Column(name = "category_id")
    private Long categoryId;

    @Column(name = "product_image_url")
    private String productImageUrl;

    @Column(name = "product_active")
    private Integer productActive;

}
