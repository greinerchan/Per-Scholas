package com.myproject.b2c.sunshine.entity;

import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;

@Entity
@Table(name = "orderitem")
@Data
public class OrderItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "orderitem_number")
    private Integer orderItemNumber;

    @Column(name = "orderitem_price")
    private BigInteger orderItemPrice;

    @Column(name = "orderitem_order_id")
    private BigInteger orderItemOrderId;

    @Column(name = "orderitem_user_id")
    private BigInteger orderItemUserId;

    @Column(name = "orderitem_user_message")
    private String orderitemUserMessage;

}
